# PPE Detection with YOLOv5

## Features
- Detect Hard Hats and Safety Vests in images
- Uses YOLOv5 pretrained model (yolov5s)

## Setup Instructions

1. Clone YOLOv5:
   ```
   git clone https://github.com/ultralytics/yolov5
   cd yolov5
   pip install -r requirements.txt
   ```

2. Copy this detect script (`detect_ppe.py`) into the yolov5 folder.

3. Add a test image in `data/images/` folder (name it `test.jpg`).

4. Run detection:
   ```
   python detect_ppe.py
   ```

Results will be saved in `runs/detect/ppe_test/`.
