import torch
from pathlib import Path
from PIL import Image
import matplotlib.pyplot as plt

# Load pretrained YOLOv5s model
model = torch.hub.load('ultralytics/yolov5', 'yolov5s', pretrained=True)

# Set confidence threshold
model.conf = 0.3

# Path to your test image
img_path = 'data/images/test.jpg'  # Replace with your image path

# Inference
results = model(img_path)

# Print results
results.print()

# Save output image
results.save(save_dir='runs/detect/ppe_test')

# Show image with detections
img_result = Image.open(Path('runs/detect/ppe_test') / 'test.jpg')
plt.imshow(img_result)
plt.axis('off')
plt.show()
